import bpy
import json


class OBJECT_OT_set_cutter_settings(bpy.types.Operator):
    bl_idname = "object.set_cutter_settings"
    bl_label = "Toggle Cutter View Settings"
    bl_description = "Toggle cutter visibility settings on all selected objects (saves and restores previous state)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        selected = context.selected_objects
        if not selected:
            self.report({"WARNING"}, "No objects selected")
            return {"CANCELLED"}

        applied = []
        restored = []

        for obj in selected:
            existing = obj.cutter_settings

            if existing:
                # Restore previous settings
                try:
                    prev = json.loads(existing)
                    obj.hide_surface_pick = prev.get("hide_surface_pick", False)
                    obj.hide_render = prev.get("hide_render", False)
                    obj.visible_camera = prev.get("visible_camera", True)
                    obj.visible_raycast = prev.get("visible_raycast", True)
                    obj.visible_diffuse = prev.get("visible_diffuse", True)
                    obj.visible_glossy = prev.get("visible_glossy", True)
                    obj.visible_transmission = prev.get("visible_transmission", True)
                    obj.visible_volume_scatter = prev.get("visible_volume_scatter", True)
                    obj.visible_shadow = prev.get("visible_shadow", True)
                    obj.display.show_shadows = prev.get("show_shadows", True)
                    obj.hide_probe_volume = prev.get("hide_probe_volume", False)
                    obj.hide_probe_sphere = prev.get("hide_probe_sphere", False)
                    obj.hide_probe_plane = prev.get("hide_probe_plane", False)
                    obj.display_type = prev.get("display_type", "SOLID")
                    obj.cutter_settings = ""
                    restored.append(obj.name)
                except (json.JSONDecodeError, KeyError):
                    self.report({"WARNING"}, f"Could not restore settings for '{obj.name}'")
            else:
                # Snapshot current settings before applying
                prev = {
                    "hide_surface_pick": obj.hide_surface_pick,
                    "hide_render": obj.hide_render,
                    "visible_camera": obj.visible_camera,
                    "visible_raycast": obj.visible_raycast,
                    "visible_diffuse": obj.visible_diffuse,
                    "visible_glossy": obj.visible_glossy,
                    "visible_transmission": obj.visible_transmission,
                    "visible_volume_scatter": obj.visible_volume_scatter,
                    "visible_shadow": obj.visible_shadow,
                    "show_shadows": obj.display.show_shadows,
                    "hide_probe_volume": obj.hide_probe_volume,
                    "hide_probe_sphere": obj.hide_probe_sphere,
                    "hide_probe_plane": obj.hide_probe_plane,
                    "display_type": obj.display_type,
                }
                obj.cutter_settings = json.dumps(prev)

                # Apply cutter settings
                obj.hide_surface_pick = True
                obj.hide_render = True
                obj.visible_camera = False
                obj.visible_raycast = False
                obj.visible_diffuse = False
                obj.visible_glossy = False
                obj.visible_transmission = False
                obj.visible_volume_scatter = False
                obj.visible_shadow = False
                obj.display.show_shadows = False
                obj.hide_probe_volume = True
                obj.hide_probe_sphere = True
                obj.hide_probe_plane = True
                obj.display_type = "WIRE"
                applied.append(obj.name)

        parts = []
        if applied:
            parts.append(f"applied to {len(applied)}")
        if restored:
            parts.append(f"restored on {len(restored)}")
        self.report({"INFO"}, f"Cutter settings {', '.join(parts)} object(s)")
        return {"FINISHED"}


class OBJECT_OT_add_remesh_and_smooth(bpy.types.Operator):
    bl_idname = "object.add_remesh_and_smooth"
    bl_label = "Add Remesh and Smooth Modifiers"
    bl_description = "Add a Remesh modifier (Smooth, octree 7) and a Smooth Corrective modifier to the active object"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        if obj is None:
            self.report({"WARNING"}, "No active object")
            return {"CANCELLED"}

        # Add Remesh modifier only if one doesn't already exist
        has_remesh = any(m.type == "REMESH" for m in obj.modifiers)
        if not has_remesh:
            remesh = obj.modifiers.new(name="Remesh", type="REMESH")
            remesh.mode = "SMOOTH"
            remesh.octree_depth = 7

        # Add Smooth Corrective modifier after the remesh
        corrective = obj.modifiers.new(name="CorrectiveSmooth", type="CORRECTIVE_SMOOTH")
        corrective.factor = 0.7
        corrective.iterations = 75
        corrective.use_only_smooth = True

        self.report({"INFO"}, f"Modifiers added to '{obj.name}'")
        return {"FINISHED"}


class OBJECT_OT_create_boolean_collection(bpy.types.Operator):
    bl_idname = "object.create_boolean_collection"
    bl_label = "Create Boolean Collections"
    bl_description = "Create a collection hierarchy for the active object with unions and cutters sub-collections"
    bl_options = {"REGISTER", "UNDO"}

    new_name: bpy.props.StringProperty(
        name="Name",
        description="Name for the object and its collection",
        default="",
    )

    def invoke(self, context, event):
        obj = context.active_object
        if obj is None:
            self.report({"WARNING"}, "No active object")
            return {"CANCELLED"}
        self.new_name = obj.name

        # Check if the object is already in a collection with the same name
        for col in bpy.data.collections:
            if obj.name in col.objects and col.name == obj.name:
                self.report({"WARNING"}, f"'{obj.name}' is already in a collection named '{col.name}'. Proceed to rename or cancel.")
                break

        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.active_object
        if obj is None:
            self.report({"WARNING"}, "No active object")
            return {"CANCELLED"}

        # Rename the object
        name = self.new_name.strip()
        if not name:
            name = obj.name
        obj.name = name
        if obj.data:
            obj.data.name = name

        # Check if already in a matching collection
        for col in bpy.data.collections:
            if obj.name in col.objects and col.name == obj.name:
                self.report({"INFO"}, f"'{obj.name}' is already in a matching collection, skipped.")
                return {"CANCELLED"}

        # Find the collection the object is currently in
        parent_collection = None
        for col in bpy.data.collections:
            if obj.name in col.objects:
                parent_collection = col
                break

        if parent_collection is None:
            # Object is only in the scene collection
            parent_collection = context.scene.collection

        # Create the new collection named after the object
        new_collection = bpy.data.collections.new(obj.name)
        parent_collection.children.link(new_collection)

        # Move the object into the new collection
        new_collection.objects.link(obj)
        parent_collection.objects.unlink(obj)

        # Create sub-collections
        unions_col = bpy.data.collections.new(f"{obj.name}_unions")
        cutters_col = bpy.data.collections.new(f"{obj.name}_cutters")
        new_collection.children.link(unions_col)
        new_collection.children.link(cutters_col)

        self.report({"INFO"}, f"Created collection hierarchy for '{obj.name}'")
        return {"FINISHED"}
