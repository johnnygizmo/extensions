# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import bpy
import sys
import os

try:
    from .operators import OBJECT_OT_set_cutter_settings, OBJECT_OT_add_remesh_and_smooth, OBJECT_OT_create_boolean_collection
except ImportError:
    _addon_dir = os.path.dirname(__file__)
    if _addon_dir not in sys.path:
        sys.path.insert(0, _addon_dir)
    from operators import OBJECT_OT_set_cutter_settings, OBJECT_OT_add_remesh_and_smooth, OBJECT_OT_create_boolean_collection

bl_info = {
    "name": "Make Cutter Settings",
    "author": "Johnny Matthews",
    "description": "Apply cutter visibility settings to selected objects",
    "blender": (4, 2, 0),
    "version": (1, 0, 0),
    "location": "View3D > Object > Set Cutter Settings",
    "category": "Object",
}


class VIEW3D_MT_set_cutter_settings(bpy.types.Menu):
    bl_label = "Set Cutter Settings"

    def draw(self, context):
        self.layout.operator(OBJECT_OT_set_cutter_settings.bl_idname)


def menu_func(self, context):
    self.layout.operator(
        OBJECT_OT_set_cutter_settings.bl_idname, icon="HIDE_OFF"
    )
    self.layout.operator(
        OBJECT_OT_add_remesh_and_smooth.bl_idname, icon="MOD_REMESH"
    )
    self.layout.operator(
        OBJECT_OT_create_boolean_collection.bl_idname, icon="OUTLINER_COLLECTION"
    )


def register():
    bpy.types.Object.cutter_settings = bpy.props.StringProperty(
        name="Cutter Settings",
        description="JSON snapshot of object settings before cutter settings were applied",
        default="",
    )
    bpy.utils.register_class(OBJECT_OT_set_cutter_settings)
    bpy.utils.register_class(OBJECT_OT_add_remesh_and_smooth)
    bpy.utils.register_class(OBJECT_OT_create_boolean_collection)
    bpy.types.VIEW3D_MT_object.append(menu_func)


def unregister():
    bpy.types.VIEW3D_MT_object.remove(menu_func)
    for cls in (OBJECT_OT_create_boolean_collection, OBJECT_OT_add_remesh_and_smooth, OBJECT_OT_set_cutter_settings):
        if hasattr(cls, "bl_rna"):
            bpy.utils.unregister_class(cls)
    del bpy.types.Object.cutter_settings
