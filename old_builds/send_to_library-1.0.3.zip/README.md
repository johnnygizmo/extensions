# Send to Library Extension for Blender

Send datablocks from your current file to an external Asset Library `.blend` file with a single action. The extension appends the datablock, marks it as an asset, populates its metadata, and saves — all via a background Blender process so your session stays responsive.

## Requirements

- Blender **5.0.1** or later

## Installation

1. Go to `Edit > Preferences > Get Extensions`.
2. Choose **Install from Disk...** and select the `send_to_library` folder or its `.zip` file.

## Setup

Before using, configure at least one Asset Library:
1. Go to `Edit > Preferences > File Paths`.
2. Under **Asset Libraries**, add a library location (any folder on your drive).

## Supported Datablock Types

| Type | Access Point |
|------|-------------|
| **Node Group** | Node Editor — right-click a Group Node |
| **Material** | Node Editor (Shader) or Material Properties — right-click |
| **Object** | 3D Viewport — right-click the active object |
| **Collection** | Outliner — right-click a Collection |

Node Trees (Geometry Nodes, Shader Nodes, etc.) and Materials can also be sent directly from the **Outliner** context menu.

## Usage

1. **Save your current file.** The background process reads from disk, so unsaved changes must be saved first (use the *Save Current File* option in the dialog if needed).
2. Right-click the datablock you want to export using one of the access points above.
3. Hover over the **"... => Asset Library"** submenu and select the target library.
4. A file dialog will open in the library folder:
   - Enter a new filename to create a new library file, **or** select an existing `.blend` to append to it.
5. Fill in the asset metadata panel on the left side of the dialog:
   - **New Name** — name for the asset in the library (pre-filled with the original name)
   - **Description** — short description shown in the Asset Browser
   - **Author** — creator credit
   - **Copyright** — copyright notice
   - **License** — license identifier (e.g. `CC0`, `GPL-3.0`)
   - **Tags** — comma-separated list of tags (e.g. `metal, hard-surface, PBR`)
   - **Save Current File** — automatically saves your file before sending if you have unsaved changes
6. Click **Save Application**.
7. Blender will briefly pause while the background process runs.
8. A **"Success! Asset saved to ..."** confirmation appears in the Info bar when complete.

## Technical Details

- The extension spawns `blender --background` and executes `backend.py` to handle all file I/O safely without modifying the current session.
- The target file is created fresh if it does not exist yet. Appending to an existing library file is not supported to prevent asset naming conflicts within a file.
- Tags entered in the dialog are split on commas and added as individual asset tags via `asset_data.tags.new()`.
- An asset preview is automatically generated after the datablock is marked as an asset.

## Troubleshooting

- **"Current file must be saved..."** — Save your `.blend` file (`Ctrl+S`) before sending, or enable *Save Current File* in the dialog.
- **"File already exists. Please choose a new filename."** — The exact filename you typed already exists; choose a different name or select the existing file directly.
- **"Failed to send asset"** — Check the System Console (`Window > Toggle System Console` on Windows) for detailed output from the background process.
- **No Asset Libraries Found** — Add at least one library under `Edit > Preferences > File Paths > Asset Libraries`.
