import bpy


def get_object_action(obj: bpy.types.Object | None) -> bpy.types.Action | None:
    """Return the active action on any object, or None."""
    if obj is None:
        return None
    if obj.animation_data and obj.animation_data.action:
        return obj.animation_data.action
    return None
