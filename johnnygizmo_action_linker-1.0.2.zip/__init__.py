bl_info = {
    "name": "Linked Object Actions",
    "author": "Johnny Matthews",
    "version": (1, 1, 0),
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > Animation > Linked Object Actions",
    "description": "Store a custom list of Actions on any object so they can be linked as real ID pointers.",
    "warning": "Depends on Blender asset dependency handling for custom ID pointers.",
    "category": "Animation",
}

# Support reloading submodules during development (F8 / Reload Scripts)
_needs_reload = "utils" in locals()
try:
    from . import utils, properties, operators, ui
except ImportError:
    # Fallback for the VS Code blender-development extension, which runs
    # __init__.py as a standalone script (no package context).
    import os
    import sys
    sys.path.insert(0, os.path.dirname(__file__))
    import utils, properties, operators, ui  # type: ignore[no-redef]

if _needs_reload:
    import importlib
    importlib.reload(utils)
    importlib.reload(properties)
    importlib.reload(operators)
    importlib.reload(ui)

import bpy

_modules = (properties, operators, ui)


def register():
    for module in _modules:
        module.register()


def unregister():
    for module in reversed(_modules):
        module.unregister()


if __name__ == "__main__":
    register()
