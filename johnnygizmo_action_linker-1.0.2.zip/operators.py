import bpy
from bpy.types import Operator

try:
    from .utils import get_object_action
except ImportError:
    from utils import get_object_action  # type: ignore[no-redef]


class LOA_OT_add_action(Operator):
    bl_idname = "loa.add_action"
    bl_label = "Add Current Action"
    bl_description = "Add the active action from the selected object to the linked action list"

    @classmethod
    def poll(cls, context):
        return get_object_action(context.object) is not None

    def execute(self, context):
        obj = context.object
        action = get_object_action(obj)
        if action is None:
            self.report({'WARNING'}, "No active action on object")
            return {'CANCELLED'}

        props = obj.linked_actions
        items = props.actions
        if any(item.action == action for item in items):
            self.report({'INFO'}, "Action is already in the list")
            return {'FINISHED'}

        item = items.add()
        item.action = action
        props.active_index = len(items) - 1
        self.report({'INFO'}, f"Added action '{action.name}'")
        return {'FINISHED'}


class LOA_OT_remove_action(Operator):
    bl_idname = "loa.remove_action"
    bl_label = "Remove Selected"
    bl_description = "Remove the selected action from the linked action list"

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.linked_actions.actions

    def execute(self, context):
        obj = context.object
        props = obj.linked_actions
        index = props.active_index
        if index < 0 or index >= len(props.actions):
            self.report({'WARNING'}, "No action selected")
            return {'CANCELLED'}

        props.actions.remove(index)
        props.active_index = min(index, len(props.actions) - 1)
        self.report({'INFO'}, "Removed selected action")
        return {'FINISHED'}


class LOA_OT_clear_actions(Operator):
    bl_idname = "loa.clear_actions"
    bl_label = "Clear List"
    bl_description = "Clear the linked action list from this object"

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.linked_actions.actions

    def execute(self, context):
        obj = context.object
        obj.linked_actions.actions.clear()
        obj.linked_actions.active_index = 0
        self.report({'INFO'}, "Cleared linked action list")
        return {'FINISHED'}


class LOA_OT_activate_action(Operator):
    bl_idname = "loa.activate_action"
    bl_label = "Activate"
    bl_description = "Set the selected action as the object's current action"

    @classmethod
    def poll(cls, context):
        obj = context.object
        if not obj:
            return False
        props = obj.linked_actions
        index = props.active_index
        return (
            0 <= index < len(props.actions)
            and props.actions[index].action is not None
        )

    def execute(self, context):
        obj = context.object
        props = obj.linked_actions
        item = props.actions[props.active_index]
        if not item or not item.action:
            self.report({'WARNING'}, "No action selected")
            return {'CANCELLED'}

        action = item.action
        anim_data = obj.animation_data_create()
        anim_data.action = action

        self.report({'INFO'}, f"Activated action '{action.name}'")
        return {'FINISHED'}


class LOA_OT_clear_object_action(Operator):
    bl_idname = "loa.clear_object_action"
    bl_label = "Clear Object Action"
    bl_description = (
        "Unlink the object's current action. For armatures, also resets all pose bone "
        "transforms. Prompts for confirmation if the action is shared or a linked asset."
    )

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and get_object_action(obj) is not None

    def invoke(self, context, event):
        action = get_object_action(context.object)
        if action is None:
            self.report({'WARNING'}, "No active action to unlink")
            return {'CANCELLED'}

        is_shared = (action.users > 1) or (
            hasattr(action, 'asset_data') and action.asset_data is not None
        )
        if is_shared:
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context):
        obj = context.object
        action = get_object_action(obj)

        if action is None:
            self.report({'INFO'}, "No action to unlink")
            return {'FINISHED'}

        is_shared = (action.users > 1) or (
            hasattr(action, 'asset_data') and action.asset_data is not None
        )
        if is_shared:
            try:
                new_action = action.copy()
                if obj.animation_data is None:
                    obj.animation_data_create()
                obj.animation_data.action = new_action
            except Exception:
                self.report({'WARNING'}, "Failed to make action single-user; aborting unlink")
                return {'CANCELLED'}

        # Unlink BEFORE resetting transforms so the depsgraph cannot re-apply
        # action curves on top of the values we are about to set.
        if obj.animation_data is not None:
            obj.animation_data.action = None
        if obj.data.animation_data is not None:
            obj.data.animation_data.action = None

        if obj.type == 'ARMATURE':
            self._reset_pose_bones(obj)

        self.report({'INFO'}, f"Unlinked action '{action.name}'")
        return {'FINISHED'}

    @staticmethod
    def _reset_pose_bones(obj: bpy.types.Object) -> None:
        """Reset location, rotation, and scale of all pose bones to rest pose."""
        for pb in obj.pose.bones:
            try:
                pb.location = (0.0, 0.0, 0.0)
            except RuntimeError:
                pass
            try:
                if pb.rotation_mode == 'QUATERNION':
                    pb.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
                elif pb.rotation_mode == 'AXIS_ANGLE':
                    pb.rotation_axis_angle = (0.0, 0.0, 1.0, 0.0)
                else:
                    pb.rotation_euler = (0.0, 0.0, 0.0)
            except RuntimeError:
                pass
            try:
                pb.scale = (1.0, 1.0, 1.0)
            except RuntimeError:
                pass


classes = (
    LOA_OT_add_action,
    LOA_OT_remove_action,
    LOA_OT_clear_actions,
    LOA_OT_activate_action,
    LOA_OT_clear_object_action,
)


def register() -> None:
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister() -> None:
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
