import bpy
from bpy.types import PropertyGroup
from bpy.props import CollectionProperty, IntProperty, PointerProperty


class LinkedAction_Item(PropertyGroup):
    action: PointerProperty(
        name="Action",
        type=bpy.types.Action,
        description="Action to include with this object",
    )


class LinkedActions_Props(PropertyGroup):
    actions: CollectionProperty(type=LinkedAction_Item)
    active_index: IntProperty(default=0)


classes = (LinkedAction_Item, LinkedActions_Props)


def register() -> None:
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.linked_actions = PointerProperty(type=LinkedActions_Props)


def unregister() -> None:
    del bpy.types.Object.linked_actions
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
