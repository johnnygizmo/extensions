import bpy
from bpy.types import Panel


class LOA_UL_action_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if item and item.action:
            layout.label(text=item.action.name, icon='ACTION')
        else:
            layout.label(text="<none>")


class LOA_PT_panel(Panel):
    bl_label = "Linked Object Actions"
    bl_idname = "LOA_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Animation'

    @classmethod
    def poll(cls, context):
        return context.object is not None

    def draw(self, context):
        layout = self.layout
        obj = context.object

        row = layout.row()
        row.operator('loa.add_action', icon='ADD')
        row.operator('loa.clear_actions', icon='TRASH')

        row = layout.row()
        row.template_list(
            "LOA_UL_action_list",
            "",
            obj.linked_actions,
            "actions",
            obj.linked_actions,
            "active_index",
            rows=4,
        )
        row.column(align=True).operator('loa.remove_action', icon='REMOVE', text='')

        if obj.linked_actions.actions:
            item = obj.linked_actions.actions[obj.linked_actions.active_index]
            if item and item.action:
                layout.label(text=f"Selected: {item.action.name}")
                layout.operator('loa.activate_action', icon='PLAY')
                layout.operator('loa.clear_object_action', icon='X', text='Clear Object Action')
            else:
                layout.label(text="Selected: <none>")
        else:
            layout.label(text="No actions in list")


classes = (
    LOA_UL_action_list,
    LOA_PT_panel,
)


def register() -> None:
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister() -> None:
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
