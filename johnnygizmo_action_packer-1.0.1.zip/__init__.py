bl_info = {
    "name": "Linked Armature Actions",
    "author": "Johnny Matthews",
    "version": (1, 0, 0),
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > Animation > Linked Armature Actions",
    "description": "Store a custom list of Actions on armature data so they can be linked as real ID pointers.",
    "warning": "Depends on Blender asset dependency handling for custom ID pointers.",
    "category": "Animation",
}

import bpy
from bpy.types import PropertyGroup, Panel, Operator
from bpy.props import CollectionProperty, PointerProperty, IntProperty


def get_armature_action(obj):
    if obj is None or obj.type != 'ARMATURE':
        return None
    if obj.animation_data and obj.animation_data.action:
        return obj.animation_data.action
    if obj.data.animation_data and obj.data.animation_data.action:
        return obj.data.animation_data.action
    return None


class AAP_OT_add_action(Operator):
    bl_idname = "aap.add_action"
    bl_label = "Add Current Action"
    bl_description = "Add the active action from the selected armature to the custom asset action list"

    @classmethod
    def poll(cls, context):
        obj = context.object
        return get_armature_action(obj) is not None

    def execute(self, context):
        armature = context.object.data
        action = get_armature_action(context.object)
        if action is None:
            self.report({'WARNING'}, "No active action on armature")
            return {'CANCELLED'}

        items = armature.asset_actions
        if any(item.action == action for item in items):
            self.report({'INFO'}, "Action is already in the list")
            return {'FINISHED'}

        item = items.add()
        item.action = action
        armature.asset_actions_index = len(items) - 1
        self.report({'INFO'}, f"Added action '{action.name}'")
        return {'FINISHED'}


class AAP_OT_remove_action(Operator):
    bl_idname = "aap.remove_action"
    bl_label = "Remove Selected"
    bl_description = "Remove the selected action from the custom armature action list"

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.type == 'ARMATURE' and obj.data.asset_actions

    def execute(self, context):
        armature = context.object.data
        index = armature.asset_actions_index
        if index < 0 or index >= len(armature.asset_actions):
            self.report({'WARNING'}, "No action selected")
            return {'CANCELLED'}

        armature.asset_actions.remove(index)
        armature.asset_actions_index = min(index, len(armature.asset_actions) - 1)
        self.report({'INFO'}, "Removed selected action")
        return {'FINISHED'}


class AAP_OT_clear_actions(Operator):
    bl_idname = "aap.clear_actions"
    bl_label = "Clear List"
    bl_description = "Clear the custom action list from this armature"

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.type == 'ARMATURE' and obj.data.asset_actions

    def execute(self, context):
        armature = context.object.data
        armature.asset_actions.clear()
        armature.asset_actions_index = 0
        self.report({'INFO'}, "Cleared custom action list")
        return {'FINISHED'}


class AAP_OT_activate_action(Operator):
    bl_idname = "aap.activate_action"
    bl_label = "Activate"
    bl_description = "Set the selected action as the armature's current action"

    @classmethod
    def poll(cls, context):
        obj = context.object
        if not obj or obj.type != 'ARMATURE':
            return False
        armature = obj.data
        index = armature.asset_actions_index
        return 0 <= index < len(armature.asset_actions) and armature.asset_actions[index].action is not None

    def execute(self, context):
        obj = context.object
        armature = obj.data
        index = armature.asset_actions_index
        item = armature.asset_actions[index]
        if not item or not item.action:
            self.report({'WARNING'}, "No action selected")
            return {'CANCELLED'}

        action = item.action
        anim_data = obj.animation_data_create()
        anim_data.action = action
        if obj.data.animation_data is not None:
            obj.data.animation_data.action = action

        self.report({'INFO'}, f"Activated action '{action.name}'")
        return {'FINISHED'}


class AAP_OT_clear_armature_action(Operator):
    bl_idname = "aap.clear_armature_action"
    bl_label = "Clear Armature Action"
    bl_description = "Reset transforms on all pose bones and unlink the armature's current action (optionally make single-user first)"

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.type == 'ARMATURE' and get_armature_action(obj) is not None

    def invoke(self, context, event):
        obj = context.object
        action = get_armature_action(obj)
        if action is None:
            self.report({'WARNING'}, "No active action to unlink")
            return {'CANCELLED'}

        is_shared = (action.users > 1) or (hasattr(action, 'asset_data') and action.asset_data is not None)
        if is_shared:
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context):
        obj = context.object

        # Reset transforms for all pose bones to rest pose
        # Equivalent to Alt+G, Alt+R, Alt+S for all bones
        for pb in obj.pose.bones:
            # Clear location
            try:
                pb.location = (0.0, 0.0, 0.0)
            except RuntimeError:
                # Bone is locked or constrained, skip
                pass
            
            # Clear rotation (respecting rotation mode)
            try:
                if pb.rotation_mode == 'QUATERNION':
                    pb.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
                else:
                    pb.rotation_euler = (0.0, 0.0, 0.0)
            except RuntimeError:
                # Bone is locked or constrained, skip
                pass
            
            # Clear scale
            try:
                pb.scale = (1.0, 1.0, 1.0)
            except RuntimeError:
                # Bone is locked or constrained, skip
                pass

        # Handle unlinking the current action
        action = get_armature_action(obj)
        if action is None:
            self.report({'INFO'}, "Transforms cleared; no action to unlink")
            return {'FINISHED'}

        is_shared = (action.users > 1) or (hasattr(action, 'asset_data') and action.asset_data is not None)
        if is_shared:
            # Make a single-user copy first
            try:
                new_action = action.copy()
                # assign the copy so it exists locally (but we'll unlink afterwards per request)
                if obj.animation_data is None:
                    obj.animation_data_create()
                obj.animation_data.action = new_action
                if obj.data.animation_data is not None:
                    obj.data.animation_data.action = new_action
            except Exception:
                self.report({'WARNING'}, "Failed to make action single-user; aborting unlink")
                return {'CANCELLED'}

        # Unlink action from object and armature data
        if obj.animation_data is not None:
            obj.animation_data.action = None
        if obj.data.animation_data is not None:
            obj.data.animation_data.action = None

        self.report({'INFO'}, f"Cleared transforms and unlinked action '{action.name}'")
        return {'FINISHED'}


class AAP_Item(PropertyGroup):
    action: PointerProperty(
        name="Action",
        type=bpy.types.Action,
        description="Action to include with this armature asset",
    )


class AAP_UL_action_list(bpy.types.UIList):
    def draw_item(
        self, context, layout, data, item, icon, active_data, active_propname, index
    ):
        if item and item.action:
            layout.label(text=item.action.name, icon='ACTION')
        else:
            layout.label(text="<none>")


class AAP_PT_panel(Panel):
    bl_label = "Linked Armature Actions"
    bl_idname = "AAP_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Animation'

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.type == 'ARMATURE'

    def draw(self, context):
        layout = self.layout
        obj = context.object
        armature = obj.data

        row = layout.row()
        row.operator('aap.add_action', icon='ADD')
        row.operator('aap.clear_actions', icon='TRASH')

        rows = 4
        row = layout.row()
        row.template_list(
            "AAP_UL_action_list",
            "asset_actions",
            armature,
            "asset_actions",
            armature,
            "asset_actions_index",
            rows=rows,
        )

        col = row.column(align=True)
        col.operator('aap.remove_action', icon='REMOVE', text='')

        if armature.asset_actions:
            item = armature.asset_actions[armature.asset_actions_index]
            if item and item.action:
                layout.label(text=f"Selected: {item.action.name}")
                layout.operator('aap.activate_action', icon='PLAY')
                layout.operator('aap.clear_armature_action', icon='X', text='Clear Armature Action')
            else:
                layout.label(text="Selected: <none>")
        else:
            layout.label(text="No actions in list")


classes = (
    AAP_Item,
    AAP_UL_action_list,
    AAP_OT_add_action,
    AAP_OT_remove_action,
    AAP_OT_clear_actions,
    AAP_OT_clear_armature_action,
    AAP_OT_activate_action,
    AAP_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Armature.asset_actions = CollectionProperty(type=AAP_Item)
    bpy.types.Armature.asset_actions_index = IntProperty(default=0)


def unregister():
    del bpy.types.Armature.asset_actions
    del bpy.types.Armature.asset_actions_index

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()
