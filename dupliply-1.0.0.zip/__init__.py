import bpy
from datetime import datetime, timezone


class OBJECT_OT_dupliply(bpy.types.Operator):
    """Duplicate the active modifier, then apply the original (keeping the copy with the original's name)"""
    bl_idname = "object.dupliply"
    bl_label = "Dupliply (Apply & Keep)"
    bl_options = {'REGISTER', 'UNDO'}

    create_backup: bpy.props.BoolProperty(
        name="Create Backup",
        description="Save a timestamped backup of the object in a dedicated scene before applying",
        default=True,
    )

    duplicate_modifier: bpy.props.BoolProperty(
        name="Duplicate Selected Modifier",
        description="Duplicate the selected modifier",
        default=True,
    )

    apply_modifier: bpy.props.BoolProperty(
        name="Apply Selected Modifier",
        description="Apply the original modifier",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None:
            return False
        if not hasattr(obj, "modifiers") or len(obj.modifiers) == 0:
            return False
        if obj.modifiers.active is None:
            return False
        return True

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "create_backup")
        layout.prop(self, "duplicate_modifier")
        layout.prop(self, "apply_modifier")

    def execute(self, context):
        obj = context.active_object

        # Optionally create a backup of the object in a dedicated scene
        if self.create_backup:
            backup_scene_name = f"{obj.name} Dupliply Backups"
            if backup_scene_name not in bpy.data.scenes:
                bpy.data.scenes.new(name=backup_scene_name)
            backup_scene = bpy.data.scenes[backup_scene_name]

            # Duplicate the object
            backup_obj = obj.copy()
            backup_obj.data = obj.data.copy()
            # Rename with Zulu timestamp suffix
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            backup_obj.name = f"{obj.name}_{timestamp}"
            # Link to backup scene (not the current scene)
            backup_scene.collection.objects.link(backup_obj)

        active_mod = obj.modifiers.active
        if active_mod is None:
            self.report({'ERROR'}, "No active modifier")
            return {'CANCELLED'}

        original_name = active_mod.name

        if not self.apply_modifier and not self.duplicate_modifier:
            self.report({'INFO'}, f"Backup created for '{obj.name}'")
            return {'FINISHED'}
        
        if self.apply_modifier and not self.duplicate_modifier:
            # Just apply without duplication
            try:
                bpy.ops.object.modifier_apply(modifier=original_name)
                self.report({'INFO'}, f"Applied '{original_name}' without reapplying")
                return {'FINISHED'}
            except RuntimeError as e:
                self.report({'ERROR'}, f"Failed to apply modifier '{original_name}': {e}")
                return {'CANCELLED'}
        
        
        

        # Duplicate the active modifier (copy appears after the original)
        copy_name = None
        if self.duplicate_modifier:
            try:
                bpy.ops.object.modifier_copy(modifier=original_name)
            except Exception as e:
                self.report({'ERROR'}, f"Failed to duplicate modifier: {e}")
                return {'CANCELLED'}

            # Find the copy (it will have a suffixed name like "Name.001")
            # It's placed directly after the original in the stack
            found_original = False
            for mod in obj.modifiers:
                if found_original:
                    copy_name = mod.name
                    break
                if mod.name == original_name:
                    found_original = True

            if copy_name is None:
                self.report({'ERROR'}, "Failed to find duplicated modifier")
                return {'CANCELLED'}

        if self.apply_modifier:
            # Apply the original modifier
            try:
                bpy.ops.object.modifier_apply(modifier=original_name)
            except RuntimeError as e:
                # If apply fails, remove the copy to leave things clean
                if self.duplicate_modifier:
                    copy_mod = obj.modifiers.get(copy_name)
                    if copy_mod is not None:
                        obj.modifiers.remove(copy_mod)
                self.report({'ERROR'}, f"Failed to apply modifier '{original_name}': {e}")
                return {'CANCELLED'}

        if self.duplicate_modifier and self.apply_modifier:
            # Rename the copy to the original's name
            copy_mod = obj.modifiers.get(copy_name)
            if copy_mod is not None:
                copy_mod.name = original_name

        self.report({'INFO'}, f"Applied '{original_name}' and kept copy")
        return {'FINISHED'}


def draw_modifier_menu(self, context):
    layout = self.layout
    layout.separator()
    layout.operator(OBJECT_OT_dupliply.bl_idname)


# Menu classes to try, in order of preference (varies by Blender version)
_MODIFIER_MENUS = [
    "OBJECT_MT_modifier_apply",
    "OBJECT_MT_modifier_context_menu",
]

_attached_menu = None


def register():
    global _attached_menu
    bpy.utils.register_class(OBJECT_OT_dupliply)

    for menu_name in _MODIFIER_MENUS:
        menu_cls = getattr(bpy.types, menu_name, None)
        if menu_cls is not None:
            menu_cls.append(draw_modifier_menu)
            _attached_menu = menu_cls
            break


def unregister():
    global _attached_menu
    if _attached_menu is not None:
        _attached_menu.remove(draw_modifier_menu)
        _attached_menu = None
    bpy.utils.unregister_class(OBJECT_OT_dupliply)
